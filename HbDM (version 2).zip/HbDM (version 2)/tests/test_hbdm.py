import io
import tempfile
from pathlib import Path
import unittest
import torch
import torch.nn.functional as F
from hbdm import HbDM, HbDMConfig, HbDMLoss, LossWeights
from hbdm.model import diffuse
from hbdm.losses import boundary_targets
from hbdm.cli import evaluate, load_tiles
from torch.utils.data import DataLoader, TensorDataset
import numpy as np


class HbDMTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(4)
        torch.set_num_threads(2)
        self.cfg = HbDMConfig(4, width=8, graph_side=4, anchor_side=2, diffusion_steps=4)

    def test_forward_gradient_and_odd_sizes(self):
        model = HbDM(self.cfg)
        x = torch.rand(2, 3, 19, 27)
        y = torch.randint(4, (2, 19, 27))
        y[:, :2] = 255
        out = model(x)
        self.assertEqual(out["logits"].shape, (2, 4, 19, 27))
        self.assertTrue(torch.allclose(out["slice_masks"].sum(1),
                                       torch.ones_like(out["slice_masks"][:, 0]), atol=1e-6))
        for graph in out["graphs"]:
            self.assertTrue(torch.allclose(graph.sum(-1), torch.ones_like(graph[..., 0]), atol=1e-6))
            self.assertGreaterEqual(graph.min().item(), 0)
        losses = HbDMLoss()(out, x, y)
        self.assertTrue(all(torch.isfinite(v) for v in losses.values()))
        losses["total"].backward()
        missing = [n for n, p in model.named_parameters() if p.grad is None]
        self.assertEqual(missing, [])
        self.assertTrue(all(torch.isfinite(p.grad).all() for p in model.parameters()))
        for component in (model.gtm, model.ssam, model.esfmg, model.decoder):
            self.assertGreater(sum(p.grad.abs().sum().item() for p in component.parameters()), 0)

    def test_diffusion_against_closed_form(self):
        s = torch.rand(2, 7, 7, dtype=torch.float64)
        s /= s.sum(-1, keepdim=True)
        y = torch.randn(2, 7, 3, dtype=torch.float64)
        alpha = .7
        expected = (1-alpha)*torch.linalg.solve(torch.eye(7)-alpha*s, y)
        actual = diffuse(s, y, alpha, 100)
        torch.testing.assert_close(actual, expected, atol=1e-10, rtol=1e-10)
        torch.testing.assert_close(diffuse(s, y, 0, 3), y)

    def test_boundaries_and_ignore(self):
        labels = torch.tensor([[[0, 0, 1, 1], [0, 0, 1, 1]]])
        edge, valid = boundary_targets(labels)
        expected = torch.tensor([[[0., 1., 1., 0.], [0., 1., 1., 0.]]])
        torch.testing.assert_close(edge, expected)
        self.assertTrue(valid.all())
        labels[0, 0, 0] = 255
        _, valid = boundary_targets(labels)
        self.assertFalse(valid[0, 0, 1])

    def test_all_ignore_and_constant_images(self):
        model = HbDM(self.cfg)
        for size in ((1, 1), (8, 9)):
            x = torch.zeros(1, 3, *size)
            out = model(x)
            y = torch.full((1, *size), 255, dtype=torch.long)
            losses = HbDMLoss()(out, x, y)
            for key in ("segmentation", "boundary", "foreground"):
                self.assertEqual(losses[key].item(), 0)
            losses["total"].backward()
            self.assertTrue(torch.isfinite(losses["total"]))

    def test_ignored_pixel_logits_do_not_change_supervised_loss(self):
        x = torch.rand(1, 3, 12, 12)
        y = torch.zeros(1, 12, 12, dtype=torch.long)
        y[:, 0] = 255
        out = HbDM(self.cfg)(x)
        before = HbDMLoss()(out, x, y)
        changed = dict(out)
        changed["logits"] = out["logits"].clone()
        changed["logits"][:, :, 0] = 100
        after = HbDMLoss()(changed, x, y)
        torch.testing.assert_close(before["segmentation"], after["segmentation"])

    def test_serialization_and_eval_determinism(self):
        model = HbDM(self.cfg).eval()
        x = torch.rand(1, 3, 13, 17)
        expected = model(x)["logits"]
        stream = io.BytesIO()
        torch.save(model.state_dict(), stream)
        stream.seek(0)
        copy = HbDM(self.cfg).eval()
        copy.load_state_dict(torch.load(stream, weights_only=True))
        torch.testing.assert_close(copy(x)["logits"], expected, rtol=0, atol=0)

    def test_overfit_tiny_sample(self):
        model = HbDM(self.cfg)
        x = torch.rand(1, 3, 12, 12)
        y = torch.zeros(1, 12, 12, dtype=torch.long)
        y[:, 4:8, 4:8] = 1
        opt = torch.optim.Adam(model.parameters(), lr=.01)
        objective = HbDMLoss(LossWeights(0, 0, 0, 0, 1))
        initial = objective(model(x), x, y)["total"].item()
        for _ in range(20):
            opt.zero_grad(set_to_none=True)
            loss = objective(model(x), x, y)["total"]
            loss.backward()
            opt.step()
        final = objective(model(x), x, y)["total"].item()
        self.assertLess(final, initial * .7)

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            HbDMConfig(3, width=7)
        with self.assertRaises(ValueError):
            HbDMConfig(3, diffusion_alpha=1)
        with self.assertRaises(ValueError):
            LossWeights(segmentation=-1)
        with self.assertRaises(ValueError):
            HbDM(self.cfg)(torch.rand(1, 4, 8, 8))
        x = torch.rand(1, 3, 8, 8)
        out = HbDM(self.cfg)(x)
        with self.assertRaises(ValueError):
            HbDMLoss()(out, x, torch.full((1, 8, 8), 4, dtype=torch.long))
        with self.assertRaises(ValueError):
            HbDMLoss(background_index=None)(out, x, torch.zeros(1, 8, 8, dtype=torch.long))

    def test_metrics_known_confusion_and_all_ignore(self):
        class Fixed(torch.nn.Module):
            config = HbDMConfig(2, width=8)

            def forward(self, x):
                pred = torch.tensor([[[0, 1], [1, 0]]])
                return {"logits": F.one_hot(pred, 2).permute(0, 3, 1, 2).float()}
        x = torch.zeros(1, 3, 2, 2)
        y = torch.tensor([[[0, 0], [1, 255]]])
        result = evaluate(Fixed(), DataLoader(TensorDataset(x, y)), "cpu")
        self.assertEqual(result["confusion"], [[1, 1], [0, 1]])
        self.assertAlmostEqual(result["mIoU"], .5)
        self.assertAlmostEqual(result["mAcc"], .75)
        self.assertAlmostEqual(result["pixel_accuracy"], 2/3)
        y.fill_(255)
        result = evaluate(Fixed(), DataLoader(TensorDataset(x, y)), "cpu")
        self.assertIsNone(result["mIoU"])

    def test_npz_contract(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/"tiles.npz"
            x = np.zeros((1, 3, 4, 5), dtype=np.float32)
            y = np.zeros((1, 4, 5), dtype=np.int64)
            np.savez(path, images=x, labels=y)
            self.assertEqual(len(load_tiles(path, 3, 4)), 1)
            y[0, 0, 0] = 255
            np.savez(path, images=x, labels=y)
            self.assertEqual(len(load_tiles(path, 3, 4)), 1)
            x[0, 0, 0, 0] = np.nan
            np.savez(path, images=x, labels=y)
            with self.assertRaises(ValueError):
                load_tiles(path, 3, 4)


if __name__ == "__main__":
    unittest.main(verbosity=2)
