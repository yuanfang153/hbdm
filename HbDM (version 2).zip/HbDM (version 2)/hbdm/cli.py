import argparse
from dataclasses import asdict
import json
from pathlib import Path
import random
import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset
from .model import HbDM, HbDMConfig
from .losses import HbDMLoss


def load_tiles(path, channels, classes, labeled=True):
    # Explicit NPZ schema avoids implicit RGB palette or geospatial rescaling.
    with np.load(path, allow_pickle=False) as data:
        x = data["images"]
        if x.ndim != 4 or x.shape[1] != channels or min(x.shape) < 1:
            raise ValueError("images must have nonempty N,C,H,W shape")
        if x.dtype != np.float32 or not np.isfinite(x).all() or x.min() < 0 or x.max() > 1:
            raise ValueError("images must be float32, finite, scaled to [0,1]")
        x = torch.from_numpy(x.copy())
        if not labeled:
            return TensorDataset(x)
        y = data["labels"]
        if y.shape != (x.shape[0], *x.shape[2:]) or not np.issubdtype(y.dtype, np.integer):
            raise ValueError("labels must be integer N,H,W")
        if not (((y >= 0) & (y < classes)) | (y == 255)).all():
            raise ValueError("labels must be class IDs or 255 (ignore)")
        tensors = [x, torch.from_numpy(y.astype(np.int64))]
        if "foreground" in data:
            fg = data["foreground"]
            if fg.shape != y.shape or not np.isfinite(fg).all() or ((fg < 0) | (fg > 1)).any():
                raise ValueError("foreground must be N,H,W, finite, in [0,1]")
            tensors.append(torch.from_numpy(fg.astype(np.float32)))
        return TensorDataset(*tensors)


@torch.no_grad()
def evaluate(model, loader, device):
    model.eval()
    k = model.config.num_classes
    confusion = torch.zeros(k, k, dtype=torch.int64, device=device)
    for batch in loader:
        x, y = batch[:2]
        y = y.to(device)
        pred = model(x.to(device))["logits"].argmax(1)
        valid = y != 255
        confusion += torch.bincount(k*y[valid] + pred[valid], minlength=k*k).reshape(k, k)
    cm = confusion.double()
    tp = cm.diag()
    union = cm.sum(0) + cm.sum(1) - tp
    present = cm.sum(1) > 0
    iou = tp / union.clamp_min(1)
    acc = tp / cm.sum(1).clamp_min(1)
    return {"mIoU": iou[union > 0].mean().item() if (union > 0).any() else None,
            "mAcc": acc[present].mean().item() if present.any() else None,
            "pixel_accuracy": (tp.sum()/cm.sum()).item() if cm.sum() else None,
            "class_iou": [v if u > 0 else None for v, u in zip(iou.tolist(), union.tolist())],
            "confusion": confusion.cpu().tolist()}


def save_checkpoint(path, model, optimizer, epoch):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    torch.save({"config": asdict(model.config), "state_dict": model.state_dict(),
                "optimizer": optimizer.state_dict(), "epoch": epoch}, temporary)
    temporary.replace(path)


def load_model(path, device):
    ckpt = torch.load(path, map_location="cpu", weights_only=True)
    model = HbDM(HbDMConfig(**ckpt["config"]))
    model.load_state_dict(ckpt["state_dict"], strict=True)
    return model.to(device)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=("train", "evaluate", "predict", "demo"))
    p.add_argument("--data", type=Path)
    p.add_argument("--val-data", type=Path)
    p.add_argument("--checkpoint", type=Path, default=Path("runs/hbdm.pt"))
    p.add_argument("--output", type=Path, default=Path("runs/predictions.npz"))
    p.add_argument("--classes", type=int, default=6)
    p.add_argument("--channels", type=int, default=3)
    p.add_argument("--width", type=int, default=32)
    p.add_argument("--graph-side", type=int, default=12)
    p.add_argument("--slices", type=int, default=3)
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--batch-size", type=int, default=2)
    p.add_argument("--lr", type=float, default=0.01)
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--background", type=int, default=0,
                   help="semantic background ID; -1 requires explicit foreground array")
    p.add_argument("--device", default="cpu")
    args = p.parse_args()
    if args.epochs < 1 or args.batch_size < 1 or not np.isfinite(args.lr) or args.lr <= 0:
        p.error("epochs, batch-size and learning rate must be positive")
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device(args.device)
    if args.mode in ("train", "demo"):
        cfg = HbDMConfig(args.classes, args.channels, args.width, args.slices,
                         graph_side=args.graph_side)
        model = HbDM(cfg).to(device)
        objective = HbDMLoss(background_index=None if args.background == -1 else args.background)
        optimizer = torch.optim.SGD(model.parameters(), lr=args.lr, momentum=0.9, weight_decay=1e-4)
        if args.mode == "demo":
            # Deliberately synthetic; this is a functionality test, not evidence of accuracy.
            y = torch.zeros(4, 32, 40, dtype=torch.long)
            y[:, 8:24, 10:30] = 1
            x = y[:, None].float().repeat(1, cfg.in_channels, 1, 1)*0.7 + torch.rand(4, cfg.in_channels, 32, 40)*0.2
            dataset = TensorDataset(x, y)
        else:
            if args.data is None:
                p.error("train requires --data")
            dataset = load_tiles(args.data, cfg.in_channels, cfg.num_classes)
        if args.background == -1 and len(dataset.tensors) != 3:
            p.error("--background -1 requires foreground in training NPZ")
        loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True, num_workers=0)
        validation = None
        if args.val_data:
            validation = DataLoader(load_tiles(args.val_data, cfg.in_channels, cfg.num_classes),
                                    batch_size=args.batch_size)
        for epoch in range(args.epochs):
            model.train()
            running = 0.
            for batch in loader:
                x, y = [a.to(device) for a in batch[:2]]
                foreground = batch[2].to(device) if len(batch) == 3 else None
                optimizer.zero_grad(set_to_none=True)
                terms = objective(model(x), x, y, foreground)
                if not torch.isfinite(terms["total"]):
                    raise FloatingPointError("nonfinite loss; checkpoint not overwritten")
                terms["total"].backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5., error_if_nonfinite=True)
                optimizer.step()
                running += terms["total"].item()*x.shape[0]
            result = {"epoch": epoch + 1, "loss": running/len(dataset)}
            if validation:
                result["validation"] = evaluate(model, validation, device)
            print(json.dumps(result), flush=True)
            save_checkpoint(args.checkpoint, model, optimizer, epoch + 1)
    else:
        if args.data is None:
            p.error("evaluate/predict requires --data")
        model = load_model(args.checkpoint, device).eval()
        cfg = model.config
        dataset = load_tiles(args.data, cfg.in_channels, cfg.num_classes, args.mode == "evaluate")
        loader = DataLoader(dataset, batch_size=args.batch_size)
        if args.mode == "evaluate":
            print(json.dumps(evaluate(model, loader, device)))
        else:
            predictions = []
            with torch.inference_mode():
                for (x,) in loader:
                    predictions.append(model(x.to(device))["logits"].argmax(1).cpu().numpy())
            args.output.parent.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(args.output, predictions=np.concatenate(predictions))


if __name__ == "__main__":
    main()
