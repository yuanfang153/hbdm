from dataclasses import dataclass
import math
import torch
from torch import Tensor, nn
import torch.nn.functional as F

MODALITIES = ("albedo", "metallic", "normal", "occlusion", "specular")


@dataclass(frozen=True)
class HbDMConfig:
    num_classes: int
    in_channels: int = 3
    width: int = 32
    slices: int = 3
    heads: int = 4
    basis_size: int = 8
    graph_side: int = 12
    anchor_side: int = 4
    diffusion_steps: int = 12
    diffusion_alpha: float = 0.8
    slice_temperature: float = 0.15

    def __post_init__(self):
        for name in ("num_classes", "in_channels", "width", "slices", "heads",
                     "basis_size", "graph_side", "anchor_side", "diffusion_steps"):
            if type(getattr(self, name)) is not int or getattr(self, name) < 1:
                raise ValueError(f"{name} must be a positive integer")
        if self.num_classes < 2 or self.slices < 2 or self.width < 4:
            raise ValueError("num_classes/slices >= 2 and width >= 4 required")
        if self.width % self.heads:
            raise ValueError("width must be divisible by heads")
        if not 0 <= self.diffusion_alpha < 1:
            raise ValueError("diffusion_alpha must be in [0, 1)")
        if not math.isfinite(self.slice_temperature) or self.slice_temperature <= 0:
            raise ValueError("slice_temperature must be finite and positive")


def resize(x: Tensor, size) -> Tensor:
    return F.interpolate(x, size=size, mode="bilinear", align_corners=False)


class ConvBlock(nn.Sequential):
    def __init__(self, ci, co, stride=1):
        # GN is a documented substitution for BN for small remote-sensing batches.
        groups = next(g for g in (8, 4, 2, 1) if co % g == 0 and co // g >= 2)
        super().__init__(nn.Conv2d(ci, co, 3, stride, 1, bias=False),
                         nn.GroupNorm(groups, co), nn.ReLU(inplace=False))


def diffuse(s: Tensor, y: Tensor, alpha: float, steps: int) -> Tensor:
    
    f = y
    for _ in range(steps):
        f = alpha * (s @ f) + (1 - alpha) * y
    return f


class GTM(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        c = cfg.width
        self.projections = nn.ModuleList([
            nn.Sequential(ConvBlock(c, c), nn.Conv2d(c, c, 1)) for _ in MODALITIES])
        self.bases = nn.Parameter(torch.randn(5, cfg.basis_size, c) / math.sqrt(c))
        self.log_gamma = nn.Parameter(torch.zeros(5))
        self.log_sigma = nn.Parameter(torch.zeros(5))
        self.kernel_mix = nn.Parameter(torch.zeros(5, 2))
        # Both mean and positive Laplace scale are learned (Eq. 24 interpretation).
        self.reconstruct = nn.Conv2d(5 * c, 2 * cfg.in_channels, 1)

    def forward(self, shared):
        b, c, h, w = shared.shape
        gh, gw = min(h, self.cfg.graph_side), min(w, self.cfg.graph_side)
        yy, xx = torch.meshgrid(torch.linspace(0, 1, gh, device=shared.device),
                                torch.linspace(0, 1, gw, device=shared.device), indexing="ij")
        xy = torch.stack((yy, xx), -1).reshape(-1, 2).float()
        spatial_d2 = torch.cdist(xy, xy).square()[None]
        maps, graphs = [], []
        for i, head in enumerate(self.projections):
            m = head(shared)
            y = F.adaptive_avg_pool2d(m, (gh, gw)).flatten(2).transpose(1, 2)
            # Eq. 3 is written as a basis product; softmax cross-attention is
            # the text's interpretation. Residual preserves local evidence.
            basis = self.bases[i].unsqueeze(0).expand(b, -1, -1)
            response = (y @ basis.transpose(1, 2) / math.sqrt(c)).softmax(-1) @ basis
            y = y + response
            # Eq. 4 feature affinity plus Eq. 9 spatial kernel, positive mixture.
            yn = F.normalize(y.float(), dim=-1)
            d2 = torch.cdist(yn, yn).square()
            gamma = F.softplus(self.log_gamma[i]) + 1e-4
            sigma = F.softplus(self.log_sigma[i]) + 1e-4
            mix = self.kernel_mix[i].softmax(0)
            affinity = mix[0] * torch.exp(-gamma * d2)
            affinity = affinity + mix[1] * torch.exp(-spatial_d2 / (2 * sigma.square()))
            # Row normalization follows the convergence paragraph, not Eq. 5.
            s = affinity / affinity.sum(-1, keepdim=True).clamp_min(1e-8)
            ranked = diffuse(s, y.float(), self.cfg.diffusion_alpha,
                             self.cfg.diffusion_steps).to(m.dtype)
            ranked = ranked.transpose(1, 2).reshape(b, c, gh, gw)
            maps.append(m + resize(ranked, (h, w)))
            graphs.append(s)
        raw = self.reconstruct(torch.cat(maps, 1))
        mean, scale = raw.chunk(2, 1)
        return maps, mean.sigmoid(), F.softplus(scale) + 1e-3, graphs


class SSAM(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        c = cfg.width
        self.modality_attention = nn.MultiheadAttention(c, cfg.heads, batch_first=True)
        self.token_projection = nn.Linear(5*c, c)
        self.context = nn.Linear(c, 5*c)
        self.dice_gain = nn.Parameter(torch.ones(cfg.heads))
        self.saliency = nn.Conv2d(5 * c, 1, 1)
        self.fuse = nn.Conv2d(5 * c, c, 1)
        self.branches = nn.ModuleList([ConvBlock(c, c) for _ in range(cfg.slices)])
        self.register_buffer("centers", torch.linspace(0, 1, cfg.slices))

    def forward(self, maps):
        # Grid cells substitute the unspecified detected interest regions.
        b, c, h, w = maps[0].shape
        rh, rw = min(h, self.cfg.anchor_side), min(w, self.cfg.anchor_side)
        pooled = [F.adaptive_avg_pool2d(m, (rh, rw)).flatten(2).transpose(1, 2)
                  for m in maps]
        tokens = self.token_projection(torch.cat(pooled, -1))
        # Eq. 15 soft Dice adhesion (positive feature responses, squared norms).
        adhesions = []
        for token in pooled:
            positive = F.softplus(token)
            norm = positive.square().sum(-1)
            adhesions.append((2 * positive @ positive.transpose(1, 2) + 1e-6) /
                             (norm[:, :, None] + norm[:, None, :] + 1e-6))
        adhesion = torch.stack(adhesions).mean(0)
        bias = adhesion[:, None] * self.dice_gain[None, :, None, None]
        bias = bias.reshape(b*self.cfg.heads, rh*rw, rh*rw)
        attended, attention = self.modality_attention(tokens, tokens, tokens,
                                                      attn_mask=bias, need_weights=True)
        context = self.context(attended).transpose(1, 2).reshape(b, 5*c, rh, rw)
        context = resize(context, (h, w)).chunk(5, 1)
        enhanced = [m + ctx for m, ctx in zip(maps, context)]
        joined = torch.cat(enhanced, 1)
        score = self.saliency(joined).sigmoid()
        # Equality of floating attention scores is not a usable grouping rule.
        # Soft bins are an explicit design choice, not an equation in the paper.
        distance = score - self.centers[None, :, None, None]
        masks = (-distance.square() / self.cfg.slice_temperature).softmax(1)
        common = self.fuse(joined)
        # Each slice has separate parameters and is gated before interaction.
        slices = [branch(common * masks[:, k:k+1]) * masks[:, k:k+1]
                  for k, branch in enumerate(self.branches)]
        return slices, masks, score, attention


class ESFMG(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        c = cfg.width
        self.theta = nn.Conv2d(c, c, 1)
        self.phi = nn.Conv2d(c, c, 1)
        self.delta = nn.Conv2d(c, c, 1)
        self.edge = nn.Sequential(ConvBlock(c, c), nn.Conv2d(c, 1, 1))
        self.out = nn.Conv2d(c, c, 1)

    def forward(self, x):
        b, c, h, w = x.shape
        gh, gw = min(h, self.cfg.graph_side), min(w, self.cfg.graph_side)
        small = F.adaptive_avg_pool2d(x, (gh, gw))
        theta = self.theta(small).flatten(2).transpose(1, 2)
        # Eq. 20 on a bounded grid; explicit X' retained only at this size.
        impression = (theta @ theta.transpose(1, 2) / math.sqrt(c)).softmax(-1)
        marked = (impression @ theta).transpose(1, 2).reshape(b, c, gh, gw)
        edge_logits = self.edge(marked)
        phi = self.phi(marked)
        # Dimensionally valid edge gating substitutes the undefined Kronecker.
        edge_features = phi * (1 + edge_logits.sigmoid())
        ah, aw = min(gh, self.cfg.anchor_side), min(gw, self.cfg.anchor_side)
        anchors = F.adaptive_max_pool2d(edge_features, (ah, aw)).flatten(2).transpose(1, 2)
        pixels = phi.flatten(2).transpose(1, 2)
        # D: B x A x N, normalized over pixels for anchor aggregation.
        d = (anchors @ pixels.transpose(1, 2) / math.sqrt(c)).softmax(-1)
        values = self.delta(marked).flatten(2).transpose(1, 2)
        region = d @ values  # dimensionally valid Eq. 22, B x A x C
        # Missing in the paper: back-project A vertices to N pixels.
        back = d.transpose(1, 2)
        back = back / back.sum(-1, keepdim=True).clamp_min(1e-8)
        restored = (back @ region).transpose(1, 2).reshape(b, c, gh, gw)
        refined = x + resize(self.out(restored), (h, w))
        return refined, resize(edge_logits, (h, w))


class HbDM(nn.Module):
    def __init__(self, config: HbDMConfig):
        super().__init__()
        self.config = config
        c = config.width
        self.stem = nn.Sequential(ConvBlock(config.in_channels, c, 2), ConvBlock(c, c))
        self.encoder = nn.Sequential(ConvBlock(c, c, 2), ConvBlock(c, c))
        self.gtm = GTM(config)
        self.ssam = SSAM(config)
        self.esfmg = nn.ModuleList([ESFMG(config) for _ in range(config.slices)])
        self.foreground = nn.Conv2d(c, 1, 1)
        self.decoder = nn.Sequential(ConvBlock(2*c, c), nn.Conv2d(c, config.num_classes, 1))

    def forward(self, image: Tensor):
        if image.ndim != 4 or image.shape[1] != self.config.in_channels:
            raise ValueError("expected B,C,H,W with configured input channels")
        if min(image.shape[0], image.shape[2], image.shape[3]) < 1:
            raise ValueError("batch and spatial dimensions must be nonempty")
        if not image.is_floating_point():
            raise TypeError("image must be floating point in [0,1]")
        size = image.shape[-2:]
        skip = self.stem(image)
        shared = self.encoder(skip)
        maps, recon, scale, graphs = self.gtm(shared)
        slices, masks, score, modality_attention = self.ssam(maps)
        refined, edges = [], []
        for branch, x in zip(self.esfmg, slices):
            feature, edge = branch(x)
            refined.append(feature)
            edges.append(edge)
        fused = sum(refined)
        edge = sum(e * masks[:, i:i+1] for i, e in enumerate(edges))
        logits = self.decoder(torch.cat((resize(fused, skip.shape[-2:]), skip), 1))
        return {"logits": resize(logits, size),
                "foreground_logits": resize(self.foreground(fused), size),
                "boundary_logits": resize(edge, size),
                "reconstruction": resize(recon, size),
                "reconstruction_scale": resize(scale, size),
                "slice_masks": masks, "saliency": score,
                "modality_attention": modality_attention, "graphs": graphs}
