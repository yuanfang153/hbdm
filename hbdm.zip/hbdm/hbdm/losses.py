"""Stable, explicitly documented interpretation of Section 3.4."""
from dataclasses import dataclass, asdict
import math
import torch
from torch import nn
import torch.nn.functional as F


@dataclass(frozen=True)
class LossWeights:
    foreground: float = 0.1
    reconstruction: float = 0.1
    partition: float = 0.01
    boundary: float = 0.1
    segmentation: float = 0.69

    def __post_init__(self):
        if any(not math.isfinite(v) or v < 0 for v in asdict(self).values()):
            raise ValueError("loss weights must be finite and nonnegative")
        if not math.isclose(sum(asdict(self).values()), 1.0, abs_tol=1e-6):
            raise ValueError("loss weights must sum to 1, following Eq. 29")


def boundary_targets(labels, ignore_index=255):
    """Four-neighbor class transitions; both endpoints are boundaries.

    Ignore pixels and their 4-neighborhood are excluded from boundary loss,
    since their unknown class can hide a transition.
    """
    valid = labels != ignore_index
    edge = torch.zeros_like(valid)
    dh = (labels[:, 1:] != labels[:, :-1]) & valid[:, 1:] & valid[:, :-1]
    dw = (labels[:, :, 1:] != labels[:, :, :-1]) & valid[:, :, 1:] & valid[:, :, :-1]
    edge[:, 1:] |= dh
    edge[:, :-1] |= dh
    edge[:, :, 1:] |= dw
    edge[:, :, :-1] |= dw
    excluded = F.max_pool2d((~valid).float()[:, None], 3, 1, 1)[:, 0] > 0
    return edge.float(), valid & ~excluded


def masked_mean(value, valid):
    return (value * valid.to(value.dtype)).sum() / valid.sum().clamp_min(1)


class HbDMLoss(nn.Module):
    def __init__(self, weights=None, ignore_index=255, background_index=0):
        super().__init__()
        self.weights = weights or LossWeights()
        self.ignore_index = ignore_index
        self.background_index = background_index

    def forward(self, out, image, labels, foreground_target=None):
        logits = out["logits"]
        if labels.shape != logits.shape[:1] + logits.shape[2:] or labels.dtype != torch.long:
            raise ValueError("labels must be int64 B,H,W matching logits")
        if image.shape != out["reconstruction"].shape:
            raise ValueError("image and reconstruction must have identical shape")
        if not torch.isfinite(image).all() or image.min() < 0 or image.max() > 1:
            raise ValueError("reconstruction training expects finite images in [0,1]")
        valid = labels != self.ignore_index
        if ((labels[valid] < 0) | (labels[valid] >= logits.shape[1])).any():
            raise ValueError("label outside configured classes")
        # Safe zero for all-ignore batches; no NaN from reduction='mean'.
        semantic = F.cross_entropy(logits, labels, ignore_index=self.ignore_index,
                                   reduction="none")
        segmentation = masked_mean(semantic, valid)
        if foreground_target is None:
            if self.background_index is None:
                raise ValueError("provide foreground_target when no semantic background exists")
            if not 0 <= self.background_index < logits.shape[1]:
                raise ValueError("background_index outside classes")
            foreground_target = (labels != self.background_index).float()
        if foreground_target.shape != labels.shape:
            raise ValueError("foreground target must have shape B,H,W")
        if not torch.isfinite(foreground_target).all() or ((foreground_target < 0) | (foreground_target > 1)).any():
            raise ValueError("foreground target must be finite in [0,1]")
        fg = F.binary_cross_entropy_with_logits(out["foreground_logits"][:, 0],
                                                foreground_target.float(), reduction="none")
        foreground = masked_mean(fg, valid)
        boundary, boundary_valid = boundary_targets(labels, self.ignore_index)
        edge_loss = F.binary_cross_entropy_with_logits(out["boundary_logits"][:, 0],
                                                       boundary, reduction="none")
        boundary_loss = masked_mean(edge_loss, boundary_valid)
        scale = out["reconstruction_scale"]
        # Proper Laplace NLL, correcting the positive exponent in printed Eq.24.
        reconstruction = ((image - out["reconstruction"]).abs() / scale
                          + torch.log(2 * scale)).mean()
        # Eq.25: population SD of per-slice mass, normalized by pixel count.
        # This encourages balanced mass; it is NOT a sparsity penalty.
        mass = out["slice_masks"].mean((2, 3))
        partition = mass.std(dim=1, correction=0).mean()
        terms = {"segmentation": segmentation, "foreground": foreground,
                 "reconstruction": reconstruction, "partition": partition,
                 "boundary": boundary_loss}
        total = sum(getattr(self.weights, key) * val for key, val in terms.items())
        return {"total": total, **terms}
