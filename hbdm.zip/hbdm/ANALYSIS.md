# HbDM manuscript analysis and implementation decisions

## Conclusion

The supplied manuscript describes a plausible research architecture for reducing attention suppression of small, faint objects through learned saliency grouping. It does not specify a uniquely reproducible network. This package is an executable, auditable **reference realization**, not an exact reproduction, official implementation, or verification of claimed benchmark performance. No trained weights or benchmark datasets were provided.

Source inspected: `Manuscript -10-22---.docx`, supplied by the user. The body text, all 29 displayed equations rendered from embedded WMF previews, and the GTM/SSAM and ESFMG diagrams were inspected. The file proceeds from Algorithm 1 to References; it contains no experimental Section 4, dataset splits, hyperparameter tables, quantitative results or ablation results, despite referring to them. Document content was treated as source material, not instructions to execute.

## What the proposed method does

The shared image encoder predicts five feature groups named albedo, metallic, normal, occlusion and specular. GTM learns bases and graph affinities, then propagates responses across similar regions. SSAM uses region adhesion and attention to group scene content by saliency. ESFMG builds nonlocal impression masks and boundary-sensitive graph anchors. A decoder combines refined features into semantic predictions.

These are latent embeddings. As Section 3.1 itself clarifies, the method does not recover calibrated material properties, physical depth, or surface normals. Reconstruction and segmentation alone do not establish disentanglement or identify the physical meaning of individual branches. The code makes no such claim.

## Equation audit and traceability

| Manuscript location | Issue or specified operation | Implementation and fidelity |
|---|---|---|
| Eqs. 1–2 | Shared encoder and five lightweight heads; backbone and channel widths absent | Four convolution blocks, output stride 4; five independent 3x3/projection heads. GroupNorm replaces stated BatchNorm for small batches. Width defaults to 32. Architecture and normalization are engineering choices. |
| Eq. 3 | Basis product; prose calls it cross attention; basis construction absent | Learned basis tokens, softmax feature-to-basis attention and residual connection. Token count defaults to 8. This is an interpretation, not literal matrix multiplication alone. |
| Eqs. 4, 9 | Gaussian feature affinity and spatial relevance | Positive learnable feature scale and spatial bandwidth, normalized positive mixture of feature and coordinate kernels. Coordinates use [0,1]; graph features are unit normalized. This simplifies the uncertain two-response kernels of Eq. 9. |
| Eqs. 5–6 | Eq. 5 is normalized adjacency D^-1/2 W D^-1/2, whereas Eq. 6 describes a combinatorial Laplacian | Use row-stochastic adjacency W / row_sum(W), as specified in the convergence paragraph. Do not call these incompatible definitions equivalent. |
| Eqs. 7–12 | Ranking energy, posterior definitions and pairwise signed update lack complete dimensions and scheduling | Use the later explicit recurrence of Eq. 13 as the operative algorithm. The energy minimizer and signed updates are not independently implemented. PyTorch autograd replaces handwritten derivatives. |
| Eqs. 13–14 | F_next = alpha S F + (1-alpha)Y; unique fixed point for 0 <= alpha < 1 | Recurrence implemented directly; default alpha=.8, 12 iterations from Y. Finite approximation, not exact convergence. Closed form checked in a separate test. The alpha contraction factor follows row stochasticity; gamma in Eq. 4 is a separate parameter. |
| Eq. 15 | Dice adhesion between unspecified interest regions | Bounded grid cells replace object proposals. Positive softplus responses produce per-modality soft Dice, averaged across modalities. No instance annotations or true depth needed. |
| Eqs. 16–19 | Query/key ordering and score function are unusual; region discovery and equality grouping undefined | Standard trainable multi-head Q/K/V attention, biased by Dice adhesion, substitutes the additive scorer and log/softmax value expression. A learned scalar saliency field and soft Gaussian bins substitute exact equality of continuous scores. These are substantial SSAM deviations. |
| Slice decomposition | Text claims targets are decoupled but supplies no hard assignment procedure | Each slice has its own convolution and ESFMG parameters, with masks before and after convolution. Shared encoder and soft overlapping assignments still permit information sharing; complete independence is not claimed. |
| Eq. 20 | X'=softmax(theta(X) theta(X)^T), then Xbar=X'theta(X) | Implemented on a pooled grid, with 1/sqrt(C) scaling. Dense nonlocal attention on full HSR tiles would be impractical. |
| Eq. 21 / Fig. 4 | Literal Kronecker between N x C and N x N expands to N^2 x CN; no reshape gives stated anchor dimensions | Substitute learned sigmoid boundary gating and adaptive max-pooled anchors. Similarity gives D of shape B x A x N, normalized over N. This does not claim to implement the printed Kronecker operator. |
| Eq. 22 | D delta(Xbar) gives A x C vertices, not an H x W feature map | Compute vertices, add normalized D-transpose back-projection to N pixels, resize and use residual refinement. Back-projection and decoder are engineering additions. |
| Eq. 23 | Foreground depth labels are mentioned but no depth source or target derivation is supplied; Yi description is not a proper class indicator | Stable binary cross entropy on semantic foreground, with explicit background ID or caller-supplied foreground map. No fabricated depth supervision. |
| Eq. 24 | Positive exp(abs(error)/scale) inside negative log makes minimization favor growing error at fixed scale | Proper Laplace NLL abs(error)/scale + log(2 scale), positive learned scale. The unspecified flipped/symmetry reconstruction term is omitted. A continuous NLL may be negative; that alone is not a failure. |
| Eq. 25 | Standard deviation of per-mask mass is described as sparsity | Compute population SD of normalized slice masses. Minimizing it balances mass and does not enforce spatial sparsity; no false sparsity claim is made. Applied to slice masks as an explicit proxy, not the dense impression matrices. |
| Eq. 26 | Boundary BCE notation has ambiguous parentheses | Standard BCE-with-logits. Targets are semantic class transitions; ignored pixels and their immediate neighbors are excluded. |
| Eqs. 27–28 | Paper advocates independent binary masks while describing exclusive semantic scene parsing | Use multiclass CE for mutually exclusive dataset labels; output C logits and argmax. This intentionally differs from independent per-class BCE and is inappropriate for overlapping multilabel targets without modification. |
| Eq. 29 | Final term lacks an explicit plus sign in the displayed equation; weights absent | Interpret as a weighted sum of five losses. Nonnegative configurable weights must sum to 1. Defaults .10 foreground, .10 reconstruction, .01 partition, .10 boundary, .69 segmentation are unvalidated choices. |
| Algorithm 1 | References several inconsistent equation numbers and supplies no complete training settings | End-to-end SGD with momentum, finite-loss/gradient checks, gradient clipping and atomic checkpoints; hyperparameters are defaults, not paper settings. |

## Tensor contracts and cost

Let B be batch size, C feature width, K saliency slices, and N <= graph_side^2 the pooled graph node count. The encoder outputs B x C x ceil(H/4) x ceil(W/4). GTM holds five B x N x N affinities. Each ESFMG slice holds one B x N x N impression matrix and B x A x N anchor assignment, A <= anchor_side^2. SSAM operates over at most A region tokens with all five modalities. Default N <= 144, A <= 16. Core attention cost is O(B(5+K)N^2 C); convolutions and stored dense feature maps still grow with tile area. This is bounded graph attention, not constant-memory whole-mosaic inference. Tile remote-sensing mosaics before use.

Output logits, reconstruction, scale, foreground and boundary predictions match the original input height and width, including odd sizes. Slice masks remain at encoder resolution and sum to one across slices. No pretrained backbone is downloaded.

## Reliability scope and unresolved scientific questions

The tests assess executable behavior, finite gradients, graph normalization, convergence against a linear solve, boundary extraction, ignore semantics, checkpoint equivalence and learning on a tiny synthetic sample. They cannot establish generalization, physical interpretability, state of the art, or improved detection of vehicles. GPU, mixed precision, distributed training, georeferenced mosaic stitching and large dataset throughput have not been validated here.

For credible empirical evaluation, obtain the actual dataset splits, channel selections, mask palettes and class policies; normalize per sensor; keep neighboring patches from the same scene out of different splits; and report per-class IoU/F1, mIoU, mAcc and boundary metrics with repeated seeds. Test vehicles/small connected components separately. Compare GTM, slicing, Dice adhesion and edge refinement through ablations against the same encoder/decoder budget. Verify whether changes benefit small objects rather than only aggregate scores.

To reproduce the authors' network, request the full experimental section, original implementation, layer table, interest-region algorithm, exact SSAM scorer, slice thresholding, valid Kronecker tensor contract, background/depth targets, reconstruction confidence/flip procedure, loss coefficients, optimization schedule and evaluation protocol.

## Software references

Implementation API choices were checked against official PyTorch documentation:

- Multi-head attention: https://docs.pytorch.org/docs/stable/generated/torch.nn.MultiheadAttention.html
- Checkpoint loading: https://docs.pytorch.org/docs/stable/generated/torch.load.html
- Serialization: https://docs.pytorch.org/docs/stable/notes/serialization

This analysis does not independently validate the manuscript's bibliography or novelty claims.
