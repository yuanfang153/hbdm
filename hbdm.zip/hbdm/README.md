# HbDM reference source code

Runnable PyTorch implementation of the manuscript's GTM → SSAM → ESFMG → decoder pipeline, with important assumptions and corrections documented in [ANALYSIS.md](ANALYSIS.md). **This is a reference implementation, not official code or an exact reproduction.** No benchmark accuracy is claimed. See [VALIDATION.md](VALIDATION.md) for executed checks.

## Install and verify

Use Python 3.10 or later in a virtual environment. Install the appropriate PyTorch build for your CPU/GPU, then from this directory:

```sh
python -m pip install -e .
python -m unittest discover -s tests -v
python -m hbdm.cli demo --epochs 2 --classes 2 --width 8 --graph-side 4
```

The demo trains on synthetic shapes solely to check the workflow. It writes a checkpoint to `runs/hbdm.pt`. Source modules depend on PyTorch; CLI additionally uses NumPy. The dependency bounds are compatibility declarations, not a claim that every release was tested. Exact tested versions are in VALIDATION.md.

## Python API

```python
import torch
from hbdm import HbDM, HbDMConfig, HbDMLoss

model = HbDM(HbDMConfig(num_classes=6, in_channels=3))
images = torch.rand(2, 3, 128, 128)  # float in [0,1]
labels = torch.randint(0, 6, (2, 128, 128))  # int64; 255 means ignore
result = model(images)
criterion = HbDMLoss(background_index=0)  # set this to your actual background ID
losses = criterion(result, images, labels)
losses["total"].backward()
prediction = result["logits"].argmax(dim=1)
```

If every class is a land-cover category and none is semantic background, use `HbDMLoss(background_index=None)` and pass a valid `foreground_target=` map. A category such as impervious surface must not silently be treated as background simply because its ID is zero. In the CLI, use `--background -1` and provide `foreground` in the training archive. If this supervision is unavailable, the foreground auxiliary objective must be redesigned or disabled in an explicitly adapted training loop.

## Dataset format

Prepare tiles as NumPy NPZ archives with explicit arrays:

| Key | Shape and type | Meaning |
|---|---|---|
| images | N,C,H,W float32 | Finite sensor bands consistently scaled to [0,1] |
| labels | N,H,W integer | Contiguous class IDs 0..classes-1; 255 ignored |
| foreground | Optional N,H,W float | Explicit binary/probabilistic foreground supervision |

```python
import numpy as np
# images and labels must be prepared from your dataset before this call.
np.savez_compressed("train.npz", images=images.astype(np.float32),
                    labels=labels.astype(np.int64))
```

Prediction archives require only `images`. Archives are loaded with `allow_pickle=False`. CLI loads each archive into memory; shard or replace TensorDataset for large datasets. RGB class palettes, nodata and sensor normalization must be mapped explicitly before packaging. ISPRS/OpenEarthMap adapters and downloaders are not included because their channel choices and labeling policies are not specified in the manuscript. For more than three bands set `--channels`; reconstruction predicts the same bands.

```sh
python -m hbdm.cli train --data train.npz --val-data val.npz --classes 6 --background 0 --epochs 100 --device cpu --checkpoint runs/hbdm.pt
python -m hbdm.cli evaluate --data test.npz --checkpoint runs/hbdm.pt
python -m hbdm.cli predict --data images.npz --checkpoint runs/hbdm.pt --output runs/predictions.npz
```

Use `--device cuda` for a compatible GPU installation (not tested here). Defaults are research starting points, not tuned settings. The CLI starts training from scratch; it does not resume optimizer/RNG/sampler state. Checkpoints store model config, state, optimizer and epoch for external extension. Evaluation loads config from the checkpoint and reports a confusion matrix, per-class IoU, mIoU over classes with nonzero union, mAcc over classes present in ground truth, and overall pixel accuracy. Empty denominators are reported as null. Ignored pixels are excluded; no class is silently dropped as background. These policies may differ from benchmark evaluators.

Predictions are N,H,W class IDs in an NPZ file, with tile order matching input order. There is no geospatial transform/CRS handling or mosaic stitching. No trained weights are included.

## Files

- `hbdm/model.py`: model, learned photo-geometric heads, graph diffusion, Dice adhesion, soft slice grouping and edge-aware anchor aggregation.
- `hbdm/losses.py`: explicit five-term objective and semantic boundary targets.
- `hbdm/cli.py`: validated NPZ loading, training, evaluation, prediction and checkpoint I/O.
- `tests/test_hbdm.py`: numerical and integration tests.
- `ANALYSIS.md`: manuscript findings, equation-by-equation decisions and scientific limitations.
- `VALIDATION.md`: actual execution results.

Checkpoint loading uses PyTorch's `weights_only=True` API, following [official documentation](https://docs.pytorch.org/docs/stable/generated/torch.load.html). Load only checkpoints whose provenance you trust.
