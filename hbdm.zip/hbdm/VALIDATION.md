# Executed validation

Executed on 2026-10-22, Windows x64 CPU, Python 3.12.14, PyTorch 2.14.1+cpu, NumPy 2.3.5. No GPU or real benchmark datasets were used.

## Automated suite

Run from the package directory: `python -m unittest discover -s tests -v`.

Ten tests passed:

1. Forward pass on odd image sizes, normalized nonnegative graphs, normalized slices, finite loss, finite gradients on every parameter and nonzero gradient flow through the main components.
2. Eq. 13 iteration at 100 steps agrees with the Eq. 14 linear solve to 1e-10 on small float64 random graphs; alpha=0 returns Y.
3. Known semantic transitions yield expected boundary pixels; unknown neighboring labels are excluded.
4. Constant images and all-ignored semantic targets, including 1x1 input, yield finite total losses and zero supervised losses.
5. Changing ignored pixels' semantic logits leaves supervised segmentation loss unchanged.
6. Saving/loading weights preserves evaluation logits exactly in the tested CPU environment.
7. Twenty Adam steps reduce single-example synthetic segmentation loss below 70% of its initial value.
8. Invalid configuration, label range, channels and missing foreground supervision are rejected.
9. Evaluation matches a hand-calculated confusion matrix; all-ignored evaluation returns null aggregate metrics.
10. NPZ schema validation accepts class IDs/ignore values and rejects nonfinite images.

These are software correctness checks, not a proof that the model improves small-object segmentation.

## Command-line integration

The following workflows completed with exit status zero:

- Two-epoch synthetic demo, width 8 and graph side 4: mean training loss 0.665728 to 0.609646.
- Reload demo checkpoint and evaluate on a separately generated two-tile synthetic archive.
- Reload checkpoint and predict: output shape 2x17x21, only configured class IDs.
- Train one epoch from an NPZ archive with validation and checkpoint writing. Training and validation used the same synthetic archive for this workflow check only; this is not an experimental split.
- Default six-class model inference on 1x3x128x160: finite 1x6x128x160 logits. Parameter count 189,865.
- Four-band input on 1x4x15x19: reconstruction has the same four bands and spatial shape.

Synthetic evaluation scores are intentionally not presented as benchmark results. The default model was not trained to convergence, and accuracy on Vaihingen, Potsdam or OpenEarthMap remains unverified.

## Remaining limits

The original manuscript lacks essential details; the explicit substitutions in ANALYSIS.md remain material. No test can establish equivalence to unavailable author code. CUDA, mixed precision, distributed execution, pretrained-backbone integration, dataset-specific preprocessing and geospatial stitching require additional validation.
